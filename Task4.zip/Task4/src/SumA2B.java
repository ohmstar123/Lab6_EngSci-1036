import java.util.Scanner;

public class SumA2B {
    public static void main(String[] args) {

        Scanner keyboard = new Scanner(System.in);

        System.out.println("Please enter two values");
        int inputA = keyboard.nextInt();
        int inputB = keyboard.nextInt();
        int total = 0;

        for (int i = inputA; i <= inputB; i++) {
            total+=i;
        }
        System.out.println("The sum of all the values before your value is: " + total);

    }
}
